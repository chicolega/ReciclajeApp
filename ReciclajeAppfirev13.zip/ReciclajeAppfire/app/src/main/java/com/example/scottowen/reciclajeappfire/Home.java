package com.example.scottowen.reciclajeappfire;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.constraint.ConstraintLayout;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class Home extends AppCompatActivity implements View.OnClickListener{

    Button botonfiltro, botonlista, botonmosaico, cerrarsesionboton;

    TextView mail;

    //static ConstraintLayout fondo;



    LinearLayout parent;
    LinearLayout padre;



    boolean vistamosaico=false;



    //Esto es el contenido de el layout busqueda.

    static Button atras;
    static EditText prov, loc, dir, num;
    static String provincia, localidad, direccion, numero;
    static Switch papel, plastico, vidrio, organico, aceite, puntlimp;
    static Boolean contpapel, contplastico, contvidrio, contorganico, contaceite, contlimp;

    //conexión con la base de datos de Firebase
    static final FirebaseDatabase miBD = FirebaseDatabase.getInstance();
    DatabaseReference ref;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        //A la creacion de la actividad se deben enlazar los campos y botones con sus varibales correspondiente

        atras=findViewById(R.id.atrasbotonfiltro);
        botonfiltro = findViewById(R.id.FiltrobotonHome);
        botonlista = findViewById(R.id.vistadelistabotonHome);
        botonmosaico = findViewById(R.id.vistamosaicabotonHome);
        cerrarsesionboton=findViewById(R.id.cerrarsesionboton);


        parent = findViewById(R.id.parent);
        padre=findViewById(R.id.padrelinear);


        //Y creamos el Linear layout padre que contendra el metodo de los 5 resultados mas valorados


        //Y llamamos al metodo que muestra los mejores 5 puntos.
          mostrarMejores();





    }


    //Metodo que realiza la consulta de busqueda y lo muestra en un dialog.
    public void mostrarResultado(){
        //En caso de que los campos esten todos vacios
        if(provincia.isEmpty() || direccion.isEmpty() || localidad.isEmpty() || numero.isEmpty()){
            Toast.makeText(this, "Los campos no deben estar vacio", Toast.LENGTH_SHORT).show();
        }
        //Esta es la consulta
        ref = miBD.getReference("Datos");
        Query query = ref.orderByChild("provincia").equalTo(provincia);
        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                for(DataSnapshot ds : dataSnapshot.getChildren()) {

                    //Pasamos el resultado de la consulta a un objeto
                    PuntoReciclaje filtropr = ds.getValue(PuntoReciclaje.class);

                    //Si cualquier contenedor esta seleccionado hace la comparacion
                    if((organico.isChecked()==true && filtropr.isContenedorGris()==true) || (papel.isChecked()==true && filtropr.isContenedorAzul()==true) || (plastico.isChecked()==true && filtropr.isContenedorAmarillo()) || (vidrio.isChecked()==true && filtropr.isContenedorVerde()) ||  (aceite.isChecked()==true && filtropr.isContenedorNaranja()) || (puntlimp.isChecked()==true && filtropr.isPuntoLimpio()) ) {

                        //Si la comparacion es correcta de todos los datos nos muestra el resultado
                        if (direccion.equals(filtropr.getDireccion()) && localidad.equals(filtropr.getLocalidad()) && numero.equals(filtropr.getNumero())) {

                            //Insertamos Los resultados en un textview y a su vez lo insertamos en un Linear layout vertical.

                            LinearLayout resultado=new LinearLayout(Home.this);
                            resultado.setOrientation(LinearLayout.VERTICAL);
                            TextView direccion=new TextView(Home.this);
                            TextView numero=new TextView(Home.this);
                            TextView localidad=new TextView(Home.this);
                            TextView provincia=new TextView(Home.this);

                                direccion.setText(" Direccion: "+filtropr.getDireccion());
                                numero.setText(" Nº: "+filtropr.getNumero());

                                    localidad.setText(" Localidad: "+filtropr.getLocalidad());
                                    provincia.setText(" Provincia: "+filtropr.getProvincia());


                                        resultado.addView(direccion);
                                        resultado.addView(numero);
                                        resultado.addView(localidad);
                                        resultado.addView(provincia);

                            setContentView(R.layout.activity_home);


                            //Creamos un dialog y le asiganmos el Linear layout previamente creado
                            AlertDialog.Builder builder = new AlertDialog.Builder(Home.this);
                            builder.setTitle("Resultado busqueda: ")
                                    .setView(resultado)




                                    .setNegativeButton("Cerrar",
                                            new DialogInterface.OnClickListener() {
                                                @Override
                                                public void onClick(DialogInterface dialog, int which) {

                                                    setContentView(R.layout.activity_home);
                                                }
                                            });


                            builder.create().show();


                        }
                    }else if(organico.isChecked()!=true && papel.isChecked()!=true && plastico.isChecked()!=true && vidrio.isChecked()!=true && aceite.isChecked()!=true && puntlimp.isChecked()!=true ){
                        Toast.makeText(Home.this, "Debes buscar almenos un contenedor", Toast.LENGTH_SHORT).show();
                    }
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }


    public void mostrarMejores() {
        //Aqui realizamos la consulta que nos devolvera los mejor valorados
        ref = miBD.getReference("Datos");
            Query query = ref.orderByChild("valor").limitToFirst(5);
            query.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                    for (DataSnapshot ds : dataSnapshot.getChildren()) {
                        PuntoReciclaje querypr = ds.getValue(PuntoReciclaje.class);

                        String direc=querypr.getDireccion();
                        String local=querypr.getLocalidad();
                        String num=querypr.getNumero();
                        String provi=querypr.getProvincia();

                        if(vistamosaico==false) {
                            mostrarLista(direc, num, local, provi);
                        }else{
                            mostrarMosaico(direc, num, local, provi);
                        }

                    }
                }


                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });


    }






    public void mostrarLista(String direc,String nume,String local,String provi){

            padre.removeAllViews();


                //Se le asigna los views a sus padres y sus hijos e insertamos los textos correspondientes


                        TextView direccion = new TextView(Home.this);
                        TextView localidad = new TextView(Home.this);
                        TextView numero = new TextView(Home.this);
                        TextView provincia = new TextView(Home.this);
                        TextView espacio = new TextView(Home.this);




                                direccion.setText(" Direccion: " + direc);
                                localidad.setText(" Localidad: " + local);
                                numero.setText(" Nº: " + nume);
                                provincia.setText(" Provincia: " + provi);
                                espacio.setText("   ");



                                parent.addView(direccion);
                                parent.addView(localidad);
                                parent.addView(numero);
                                parent.addView(provincia);
                                parent.addView(espacio);




    }


    public void mostrarMosaico(String direc,String nume,String local,String provi){

        parent.removeAllViews();
        System.out.println("Ha entrado en mosaico");

        //Este metodo crea Un Linear layout horizontal hijo de Linear layout padre




        LinearLayout son = new LinearLayout(Home.this);
        son.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        son.setOrientation(LinearLayout.HORIZONTAL);


        //Se le asigna los views a sus padres y sus hijos e insertamos los textos correspondientes


        padre.addView(son);

        LinearLayout grandson = new LinearLayout(Home.this);
        grandson.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        grandson.setOrientation(LinearLayout.VERTICAL);

        LinearLayout grandson2 = new LinearLayout(Home.this);
        grandson2.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        grandson2.setOrientation(LinearLayout.VERTICAL);

        son.addView(grandson);
        son.addView(grandson2);


        TextView direccion = new TextView(Home.this);
        TextView localidad = new TextView(Home.this);
        TextView numero = new TextView(Home.this);
        TextView provincia = new TextView(Home.this);
        TextView espacio = new TextView(Home.this);

        grandson.addView(direccion);
        grandson2.addView(numero);
        grandson.addView(localidad);
        grandson2.addView(provincia);
        grandson.addView(espacio);



        direccion.setText(" Direccion: " + direc);
        localidad.setText(" Localidad: " + local);
        numero.setText(" Nº: " + nume);
        provincia.setText(" Provincia: " + provi);








    }




    @Override
    public void onClick(View v) {
        //fondo.removeView(lista);
        switch (v.getId()) {
            case R.id.vistadelistabotonHome:
                vistamosaico=false;

                mostrarMejores();
                break;

            case R.id.vistamosaicabotonHome:
                vistamosaico=true;
                mostrarMejores();
                break;

            case R.id.añadirid:
                Intent intent = new Intent(this, Contenido.class);
                startActivity(intent);
                break;

            case R.id.FiltrobotonHome:
                setContentView(R.layout.busqueda);
                break;

            case R.id.cerrarsesionboton:
                finish();
                break;

        }
    }




    public void busqueda(View v){

        //Este metodo asigana cada campo del layout busqueda a su variable correspondiente

        atras = findViewById(R.id.atrasbotonfiltro);

        prov = findViewById(R.id.provinciatextofiltro);
        loc = findViewById(R.id.localidadtextofiltro);
        dir = findViewById(R.id.textobusquedadireccion);
        num = findViewById(R.id.numerotextofiltro);
        papel = findViewById(R.id.contenedorazul);
        plastico = findViewById(R.id.contenedoramarillo);
        vidrio = findViewById(R.id.contendeorverde);
        organico = findViewById(R.id.contenedorgris);
        aceite = findViewById(R.id.contenedornaranja);
        puntlimp = findViewById(R.id.puntolimpiocontenedor);
       provincia=prov.getText().toString();

        provincia=prov.getText().toString();
        localidad=loc.getText().toString();
        direccion=dir.getText().toString();
        numero=num.getText().toString();


        switch (v.getId()) {

            //Este boton te devulve al layout home
            case R.id.atrasbotonfiltro:
                setContentView(R.layout.activity_home);
                break;
            //Este boton llama a al metodo que realiza la busqueda y la consulta.
            case R.id.busquedabutton:
                 mostrarResultado();
                 break;
        }


    }


}




