package com.example.scottowen.reciclajeappfire;

public class PuntoReciclaje {

    boolean contenedorAmarillo,contenedorAzul,contenedorGris,contenedorVerde,contenedorNaranja,puntoLimpio;
    private String provincia,localidad,direccion,numero;
    private int valor;


    //Implementamos los constructores.
    public PuntoReciclaje() {
    this.contenedorNaranja=false;


    }


    public PuntoReciclaje(boolean contenedorAmarillo, boolean contenedorAzul, boolean contenedorGris, boolean contenedorVerde, boolean contenedorNaranja, boolean puntoLimpio, String provincia, String localidad, String direccion, String numero, int valor) {
        this.contenedorAmarillo = contenedorAmarillo;
        this.contenedorAzul = contenedorAzul;
        this.contenedorGris = contenedorGris;
        this.contenedorVerde = contenedorVerde;
        this.contenedorNaranja = contenedorNaranja;
        this.puntoLimpio = puntoLimpio;
        this.provincia = provincia;
        this.localidad = localidad;
        this.direccion = direccion;
        this.numero = numero;
        this.valor=0;

    }


    //Implementamos los metodos get y set de las variables.
    public boolean isContenedorAmarillo() {
        return contenedorAmarillo;
    }

    public void setContenedorAmarillo(boolean contenedorAmarillo) {
        this.contenedorAmarillo = contenedorAmarillo;
    }

    public boolean isContenedorAzul() {
        return contenedorAzul;
    }

    public void setContenedorAzul(boolean contenedorAzul) {
        this.contenedorAzul = contenedorAzul;
    }

    public boolean isContenedorGris() {
        return contenedorGris;
    }

    public void setContenedorGris(boolean contenedorGris) {
        this.contenedorGris = contenedorGris;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public boolean isContenedorVerde() {
        return contenedorVerde;
    }

    public void setContenedorVerde(boolean contenedorVerde) {
        this.contenedorVerde = contenedorVerde;
    }

    public boolean isContenedorNaranja() {
        return contenedorNaranja;
    }

    public void setContenedorNaranja(boolean contenedorNaranja) {
        this.contenedorNaranja = contenedorNaranja;
    }

    public boolean isPuntoLimpio() {
        return puntoLimpio;
    }

    public void setPuntoLimpio(boolean puntoLimpio) {
        this.puntoLimpio = puntoLimpio;
    }

    public String getProvincia() {
        return provincia;
    }

    public void setProvincia(String provincia) {
        this.provincia = provincia;
    }

    public String getLocalidad() {
        return localidad;
    }

    public void setLocalidad(String localidad) {
        this.localidad = localidad;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public int getValor() {
        return valor;
    }

    public void setValor(int valor) {
        this.valor = valor;
    }
}
