package com.example.scottowen.reciclajeappfire;

import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.constraint.ConstraintLayout;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class Home extends AppCompatActivity implements View.OnClickListener{

    Button botonfiltro, botonlista, botonmosaico, botonmapa;

    TextView mail;

    static ConstraintLayout fondo;

    LinearLayout parent;

    boolean vistamosaico=false;



    //Esto es el contenido de el layout busqueda.

    static Button atras;
    static EditText prov, loc, dir, num;
    static String provincia, localidad, direccion, numero;
    static Switch papel, plastico, vidrio, organico, aceite, puntlimp;
    static Boolean contpapel, contplastico, contvidrio, contorganico, contaceite, contlimp;

    //conexión con la base de datos de Firebase
    static final FirebaseDatabase miBD = FirebaseDatabase.getInstance();
    DatabaseReference ref;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        botonfiltro = findViewById(R.id.FiltrobotonHome);
        botonlista = findViewById(R.id.vistadelistabotonHome);
        botonmosaico = findViewById(R.id.vistamosaicabotonHome);
        botonmapa = findViewById(R.id.mapabotonHome);

        fondo = findViewById(R.id.fondo);

        parent = new LinearLayout(Home.this);
        parent.setOrientation(LinearLayout.VERTICAL);

        fondo.addView(parent);




        mail = (TextView) findViewById(R.id.NombreusuariolabelHome);
        mail.setText("");







        mostrarMejores();

    }


    public void mostrarMejores() {
        //Aqui realizamos la query que nos devolvera los mejor valorados
        ref = miBD.getReference("Datos");



            Query query = ref.orderByChild("valor").limitToFirst(5);
            query.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                    for (DataSnapshot ds : dataSnapshot.getChildren()) {
                        PuntoReciclaje querypr = ds.getValue(PuntoReciclaje.class);

                        if(vistamosaico==false) {

                            LinearLayout son = new LinearLayout(Home.this);
                            son.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
                            son.setOrientation(LinearLayout.HORIZONTAL);


                                LinearLayout grandson = new LinearLayout(Home.this);
                                grandson.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT));
                                grandson.setOrientation(LinearLayout.VERTICAL);

                                    LinearLayout grandson2 = new LinearLayout(Home.this);
                                    grandson2.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT));
                                    grandson2.setOrientation(LinearLayout.VERTICAL);

                                        parent.addView(son);
                                        son.addView(grandson);
                                        son.addView(grandson2);

                                            TextView direccion = new TextView(Home.this);
                                            TextView localidad = new TextView(Home.this);
                                            TextView numero = new TextView(Home.this);
                                            TextView provincia = new TextView(Home.this);


                                                grandson.addView(direccion);
                                                grandson.addView(localidad);
                                                grandson2.addView(numero);
                                                grandson2.addView(provincia);

                                                    direccion.setText(" Direccion:" + querypr.getDireccion());
                                                    localidad.setText(" Localidad:" + querypr.getLocalidad());
                                                    numero.setText(" Nº:" + querypr.getNumero());
                                                    provincia.setText("Provincia:" + querypr.getProvincia());



                        }else {
                            LinearLayout son = new LinearLayout(Home.this);
                            son.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
                            son.setOrientation(LinearLayout.HORIZONTAL);


                            LinearLayout grandson = new LinearLayout(Home.this);
                            grandson.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT));
                            grandson.setOrientation(LinearLayout.VERTICAL);


                            parent.addView(son);
                            son.addView(grandson);


                            TextView direccion = new TextView(Home.this);
                            direccion.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
                            TextView localidad = new TextView(Home.this);
                            localidad.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
                            TextView numero = new TextView(Home.this);
                            numero.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
                            TextView provincia = new TextView(Home.this);
                            provincia.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));


                            grandson.addView(direccion);
                            grandson.addView(numero);
                            grandson.addView(localidad);
                            grandson.addView(provincia);

                            direccion.setText(" Direccion:" + querypr.getDireccion());
                            localidad.setText(" Localidad:" + querypr.getLocalidad());
                            numero.setText(" Nº:" + querypr.getNumero());
                            provincia.setText("Provincia:" + querypr.getProvincia());
                        }

                    }
                }


                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });


    }


    public void mostrarbusqueda(String direc,String nume,String local,String provi){
        

    }


    @Override
    public void onClick(View v) {
        //fondo.removeView(lista);
        switch (v.getId()) {
            case R.id.vistadelistabotonHome:
                vistamosaico=false;
                parent.removeAllViews();
                mostrarMejores();
                break;

            case R.id.vistamosaicabotonHome:
                vistamosaico=true;
                parent.removeAllViews();
                mostrarMejores();
                break;

            case R.id.añadirid:
                Intent intent = new Intent(this, Contenido.class);
                startActivity(intent);
                break;

            case R.id.FiltrobotonHome:
                setContentView(R.layout.busqueda);
                break;

        }
    }

    public void busqueda(View v){
        atras = findViewById(R.id.atrasbotonfiltro);

        prov = findViewById(R.id.provinciatextofiltro);
        loc = findViewById(R.id.localidadtextofiltro);
        dir = findViewById(R.id.textobusquedadireccion);
        num = findViewById(R.id.numerotextofiltro);
        papel = findViewById(R.id.contenedorazul);
        plastico = findViewById(R.id.contenedoramarillo);
        vidrio = findViewById(R.id.contendeorverde);
        organico = findViewById(R.id.contenedorgris);
        aceite = findViewById(R.id.contenedornaranja);
        puntlimp = findViewById(R.id.puntolimpiocontenedor);
       provincia=prov.getText().toString();

        provincia=prov.getText().toString();
        localidad=loc.getText().toString();
        direccion=dir.getText().toString();
        numero=num.getText().toString();


        if(provincia.isEmpty()){
            Toast.makeText(this, "El campo provincia no debe estar vacio", Toast.LENGTH_SHORT).show();
        }

        switch (v.getId()) {
            case R.id.atrasbotonfiltro:
                setContentView(R.layout.activity_home);
                break;

            case R.id.busquedabutton:

                parent.removeAllViews();

                Query query = ref.orderByChild("provincia").equalTo(provincia);
                query.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                        for(DataSnapshot ds : dataSnapshot.getChildren()) {
                            PuntoReciclaje filtropr = ds.getValue(PuntoReciclaje.class);

                            //Si localidad esta vacia
                            if(localidad.isEmpty()){

                                //Si localidad y direccion estan vacias
                                if(direccion.isEmpty()){

                                    //Si localidad direccion y numero estan vacios
                                    if(numero.isEmpty()){
                                        //Comprueba que contenedor este marcado para buscar
                                        if((organico.isChecked()==true && filtropr.isContenedorGris()==true) || (papel.isChecked()==true && filtropr.isContenedorAzul()==true) || (plastico.isChecked()==true && filtropr.isContenedorAmarillo()) || (vidrio.isChecked()==true && filtropr.isContenedorVerde()) ||  (aceite.isChecked()==true && filtropr.isContenedorNaranja()) || (puntlimp.isChecked()==true && filtropr.isPuntoLimpio()) ) {

                                            String direccionado=filtropr.getDireccion();
                                            String numerico=filtropr.getNumero();
                                            String localico=filtropr.getLocalidad();
                                            String provincial= filtropr.getProvincia();

                                           mostrarbusqueda(direccionado,numerico,localico,provincial);
                                            System.out.println("filtrado solo por provincia" + direccionado);
                                        }
                                        //Si localidad y direccion esta vacia pero numero no
                                    }else{
                                        if(numero.equals(filtropr.getNumero())){
                                            //Comprueba que contenedor este marcado para buscar
                                            if((organico.isChecked()==true && filtropr.isContenedorGris()==true) || (papel.isChecked()==true && filtropr.isContenedorAzul()==true) || (plastico.isChecked()==true && filtropr.isContenedorAmarillo()) || (vidrio.isChecked()==true && filtropr.isContenedorVerde()) ||  (aceite.isChecked()==true && filtropr.isContenedorNaranja()) || (puntlimp.isChecked()==true && filtropr.isPuntoLimpio()) ) {
                                                System.out.println("Provincia, numero " + filtropr.getDireccion());
                                            }
                                        }
                                    }

                                    //Si localidad esta vacia pero direccion no
                                }else{

                                    //Si localidad y numero estan vacios pero direccion no
                                    if(numero.isEmpty()){
                                        //Comprueba que direccion sea igual
                                        if(direccion.equals(filtropr.getDireccion())){
                                            //Comprueba que contenedor este marcado para buscar
                                            if((organico.isChecked()==true && filtropr.isContenedorGris()==true) || (papel.isChecked()==true && filtropr.isContenedorAzul()==true) || (plastico.isChecked()==true && filtropr.isContenedorAmarillo()) || (vidrio.isChecked()==true && filtropr.isContenedorVerde()) ||  (aceite.isChecked()==true && filtropr.isContenedorNaranja()) || (puntlimp.isChecked()==true && filtropr.isPuntoLimpio()) ) {
                                                System.out.println("Provincia y direccion" + filtropr.getDireccion());
                                            }
                                        }

                                        //Si localidad esta vacia pero direccion y numeros no
                                    }else{
                                        if(direccion.equals(filtropr.getDireccion())&& numero.equals(filtropr.getNumero())){
                                            //Comprueba que contenedor este marcado para buscar
                                            if((organico.isChecked()==true && filtropr.isContenedorGris()==true) || (papel.isChecked()==true && filtropr.isContenedorAzul()==true) || (plastico.isChecked()==true && filtropr.isContenedorAmarillo()) || (vidrio.isChecked()==true && filtropr.isContenedorVerde()) ||  (aceite.isChecked()==true && filtropr.isContenedorNaranja()) || (puntlimp.isChecked()==true && filtropr.isPuntoLimpio()) ) {
                                                System.out.println("provincia numero y direccion");
                                            }
                                        }

                                    }

                                }
                                //Si localidad no esta vacia
                            }else{

                                //Si localidad no esta vacia pero direccion si
                                if(direccion.isEmpty()){

                                    //Si localidad no esta vacia pero direccion y numero si
                                    if(numero.isEmpty()){
                                        if(localidad.equals(filtropr.getLocalidad())) {
                                            if((organico.isChecked()==true && filtropr.isContenedorGris()==true) || (papel.isChecked()==true && filtropr.isContenedorAzul()==true) || (plastico.isChecked()==true && filtropr.isContenedorAmarillo()) || (vidrio.isChecked()==true && filtropr.isContenedorVerde()) ||  (aceite.isChecked()==true && filtropr.isContenedorNaranja()) || (puntlimp.isChecked()==true && filtropr.isPuntoLimpio()) ) {
                                                System.out.println("Provincia y localidad " + filtropr.getDireccion());
                                            }
                                        }

                                        //Si localidad no esta vacia direccion si pero numero no
                                    }else{
                                        if(localidad.equals(filtropr.getLocalidad())&&numero.equals(filtropr.getNumero())){
                                            if((organico.isChecked()==true && filtropr.isContenedorGris()==true) || (papel.isChecked()==true && filtropr.isContenedorAzul()==true) || (plastico.isChecked()==true && filtropr.isContenedorAmarillo()) || (vidrio.isChecked()==true && filtropr.isContenedorVerde()) ||  (aceite.isChecked()==true && filtropr.isContenedorNaranja()) || (puntlimp.isChecked()==true && filtropr.isPuntoLimpio()) ) {
                                                System.out.println("provincia,localidad,numero");
                                            }
                                        }
                                    }

                                    //Si localidad y direccion no esta vacia
                                }else{

                                    //Si localidad y direccion no esta vacia pero numero si
                                    if(numero.isEmpty()){
                                        if(localidad.equals(filtropr.getLocalidad()) && direccion.equals(filtropr.getDireccion())){
                                            if((organico.isChecked()==true && filtropr.isContenedorGris()==true) || (papel.isChecked()==true && filtropr.isContenedorAzul()==true) || (plastico.isChecked()==true && filtropr.isContenedorAmarillo()) || (vidrio.isChecked()==true && filtropr.isContenedorVerde()) ||  (aceite.isChecked()==true && filtropr.isContenedorNaranja()) || (puntlimp.isChecked()==true && filtropr.isPuntoLimpio()) ) {
                                                System.out.println("provincia,localidad,direccion" + filtropr.getDireccion());
                                            }
                                        }

                                        //Si localidad , direccion ,numero  no esta vacia
                                    }else{
                                        if(localidad.equals(filtropr.getLocalidad())&& direccion.equals(filtropr.getDireccion())&& numero.equals(filtropr.getNumero())){
                                            if((organico.isChecked()==true && filtropr.isContenedorGris()==true) || (papel.isChecked()==true && filtropr.isContenedorAzul()==true) || (plastico.isChecked()==true && filtropr.isContenedorAmarillo()) || (vidrio.isChecked()==true && filtropr.isContenedorVerde()) ||  (aceite.isChecked()==true && filtropr.isContenedorNaranja()) || (puntlimp.isChecked()==true && filtropr.isPuntoLimpio()) ) {
                                                System.out.println("provincia,localidad,direccion,numero" + filtropr.getDireccion());
                                            }
                                        }
                                    }


                                }
                            }




                        }

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });


                setContentView(R.layout.activity_home);
                break;
        }


    }


}




