package com.example.scottowen.accesoadatos;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import java.text.SimpleDateFormat;

public class Agregarinventario extends AppCompatActivity{

    Button agregar;

    private final int PICK_IMAGE_REQUEST=1;
    private Uri filePath;



    public static Producto productos;

    EditText nombre,fecha,descripcion;
    Button btnchoose;
    ImageView imagenproducto;
    SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy");

    static FirebaseStorage storagebd=FirebaseStorage.getInstance();
    static StorageReference storagereference=storagebd.getReference("Productos");

    static FirebaseDatabase miBD = FirebaseDatabase.getInstance();
    static DatabaseReference ref = miBD.getReference("Productos");


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agregarinventario);

        //Asigna el componente visual con los correspondientes inputs


        agregar=findViewById(R.id.addbutton);

        nombre=findViewById(R.id.nombreproducto);
        descripcion=findViewById(R.id.descripcionproducto);
        fecha=findViewById(R.id.fechaproducto);
        btnchoose=findViewById(R.id.choose);
        imagenproducto=findViewById(R.id.imagenProducto);

        btnchoose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                chooseImage();
            }
        });

        //Inicializa producto
        productos=new Producto();



        //Metodo agregar al clickar en boton agregar
        agregar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                uploadFile();



            }
        });


    }


    private void chooseImage(){
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent,PICK_IMAGE_REQUEST);
    }


    private void uploadFile(){

        if(filePath !=null){
            final StorageReference fileReference=storagereference.child(System.currentTimeMillis()+"."+getFileExtension(filePath));

            fileReference.putFile(filePath).addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {
                    Task<Uri> uriTask = task.getResult().getStorage().getDownloadUrl();
                    while(!uriTask.isComplete());
                    Uri downloadUrl = uriTask.getResult();

                    productos.setImagen(downloadUrl.toString());

                    productos.setImagen(downloadUrl.toString());

                    nuevoprod();
                }
            });

        }else{
            Toast.makeText(this, "No hay archivos seleccionados", Toast.LENGTH_SHORT).show();
        }
    }


    private String getFileExtension(Uri uri){

        ContentResolver cR=getContentResolver();
        MimeTypeMap mime =MimeTypeMap.getSingleton();


        return mime.getExtensionFromMimeType(cR.getType(uri));
    }

    public void nuevoprod(){

        ProductoDaoImpl pdao=new ProductoDaoImpl();
        String nombrenew=nombre.getText().toString();
        String descripcionnew=descripcion.getText().toString();
        String fechanew=fecha.getText().toString();


        productos.setNombre(nombrenew);
        productos.setDescripcion(descripcionnew);
        productos.setFecha(fechanew);

        String codigo=Agregarinventario.ref.push().getKey();

        productos.setUploadID(codigo);



        pdao.crearProducto(productos);

        Intent intent = new Intent(Agregarinventario.this,MainActivity.class);
        startActivity(intent);



    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode== PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() !=null){
            filePath =data.getData();
            Picasso.with(this).load(filePath).into(imagenproducto);

        }


    }
}

