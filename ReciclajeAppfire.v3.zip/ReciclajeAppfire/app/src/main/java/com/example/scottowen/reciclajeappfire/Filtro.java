package com.example.scottowen.reciclajeappfire;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Filtro extends AppCompatActivity implements View.OnClickListener {

    Button atras;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_filtro);

        atras=(Button)findViewById(R.id.atrasbotonfiltro);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.atrasbotonfiltro:
                Intent intent = new Intent(this, Home.class);
                startActivity(intent);
                break;
        }
    }
}
