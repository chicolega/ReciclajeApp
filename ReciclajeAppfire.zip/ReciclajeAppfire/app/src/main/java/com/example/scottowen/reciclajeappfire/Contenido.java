package com.example.scottowen.reciclajeappfire;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Contenido extends AppCompatActivity implements View.OnClickListener {

    EditText provincia, localidad, direccion, numero;
    ImageButton papel, plastico, vidrio, organico, puntolimpio, aceite;


    boolean papelselec=false;
    boolean plasticoselec=false;
    boolean vidrioselec=false;
    boolean organicoselec=false;
    boolean puntolimpioselec=false;
    boolean aceiteselec=false;



    static FirebaseDatabase miBD = FirebaseDatabase.getInstance();
    DatabaseReference ref = miBD.getReference("Datos");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contenido);

        provincia = (EditText) findViewById(R.id.provinciaid);
        localidad = (EditText) findViewById(R.id.localidaid);
        direccion = (EditText) findViewById(R.id.direccionid);
        numero = (EditText) findViewById(R.id.numeroid);

        papel=(ImageButton)findViewById(R.id.papelbotoncontenido);
        plastico=(ImageButton)findViewById(R.id.plasticobotoncontenido);
        vidrio=(ImageButton)findViewById(R.id.vidriobotoncontenido);
        organico=(ImageButton)findViewById(R.id.organicobotoncontenido);
        puntolimpio=(ImageButton)findViewById(R.id.puntolimpiobotoncontenido);
        aceite=(ImageButton)findViewById(R.id.aceitebotoncontenido);


    }

    @Override
    public void onClick(View v) {

        String dir=direccion.getText().toString();
        String prov=provincia.getText().toString();
        String loc=localidad.getText().toString();
        String num=numero.getText().toString();







        switch (v.getId()) {

        case R.id.papelbotoncontenido:



            if(papelselec == false){
            papel.setBackgroundResource(R.drawable.contenedordebasurapf);
                papelselec = true;
            }else{
                papel.setBackgroundResource(R.drawable.contenedordebasurap);
                papelselec=false;
            }



            break;

        case R.id.plasticobotoncontenido:

            if(plasticoselec == false){
                plastico.setBackgroundResource(R.drawable.contenedordebasuraplfull);
                plasticoselec= true;
            }else{
                plastico.setBackgroundResource(R.drawable.contenedordebasurapl);
                plasticoselec=false;
            }

        break;

        case R.id.vidriobotoncontenido:

            if(vidrioselec == false){
                vidrio.setBackgroundResource(R.drawable.contenedordebasuravfull);
                vidrioselec = true;
            }else{
                vidrio.setBackgroundResource(R.drawable.contenedordebasurav);
                vidrioselec=false;
            }

        break;
        case R.id.organicobotoncontenido:

            if(organicoselec == false){
                organico.setBackgroundResource(R.drawable.contenedordebasura);
                organicoselec = true;
            }else{
                organico.setBackgroundResource(R.drawable.contenedordebasuraf);
                organicoselec=false;
            }

        break;
        case R.id.puntolimpiobotoncontenido:

            if(puntolimpioselec == false){
                puntolimpio.setBackgroundResource(R.drawable.contenedordebasurafull);
                puntolimpioselec = true;
            }else{
                puntolimpio.setBackgroundResource(R.drawable.contenedorpuntolimpio);
                puntolimpioselec=false;
            }
        break;
        case R.id.aceitebotoncontenido:
            if(aceiteselec == false){
                aceite.setBackgroundResource(R.drawable.contenedordebasuraac);
                aceiteselec = true;
            }else{
                aceite.setBackgroundResource(R.drawable.contenedordebasuraacfull);
                aceiteselec=false;
            }
        break;

            case R.id.añadircont:
                nuevocont(dir,prov,loc,num);
                break;
            case R.id.cancelarid:
                Intent intent = new Intent(this,Home.class);
                startActivity(intent);

                break;

        }

    }


    public void nuevocont(String direccion,String provincia,String localidad,String numero){

        DatabaseReference refPush=ref.push();

        DatabaseReference refprovincia = refPush.child("Provincia");
        refprovincia.setValue(provincia);

        DatabaseReference reflocalidad = refPush.child("Localidad");
        reflocalidad.setValue(localidad);

        DatabaseReference refdireccion = refPush.child("Direccion");
        refdireccion.setValue(direccion);

        DatabaseReference refnumero = refPush.child("Numero");
        refnumero.setValue(numero);

        DatabaseReference refpapel = refPush.child("Contenedor azul");
        refpapel.setValue(papelselec);

        DatabaseReference refplastico = refPush.child("Contenedor amarillo");
        refplastico.setValue(plasticoselec);

        DatabaseReference refvidrio = refPush.child("Contenedor verde");
        refvidrio.setValue(vidrioselec);

        DatabaseReference reforganico = refPush.child("Contenedor gris");
        reforganico.setValue(organicoselec);

        DatabaseReference refpuntolimpio= refPush.child("Contenedor punto limpio");
        refpuntolimpio.setValue(puntolimpioselec);

        DatabaseReference refaceite = refPush.child("Contenedor naranja");
        refaceite.setValue(aceiteselec);


    }


}
