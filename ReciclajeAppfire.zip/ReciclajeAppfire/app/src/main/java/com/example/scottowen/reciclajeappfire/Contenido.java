package com.example.scottowen.reciclajeappfire;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Contenido extends AppCompatActivity implements View.OnClickListener {

    EditText provincia, localidad, direccion, numero;
    CheckBox papel, plastico, vidrio, organico, puntol, aceite;

    static FirebaseDatabase miBD = FirebaseDatabase.getInstance();
    DatabaseReference ref = miBD.getReference("Datos");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contenido);

        provincia = (EditText) findViewById(R.id.provinciaid);
        localidad = (EditText) findViewById(R.id.localidaid);
        direccion = (EditText) findViewById(R.id.direccionid);
        numero = (EditText) findViewById(R.id.numeroid);

        papel = (CheckBox) findViewById(R.id.contazul);
        plastico = (CheckBox) findViewById(R.id.contamarillo);
        vidrio = (CheckBox) findViewById(R.id.contverde);
        organico = (CheckBox) findViewById(R.id.contgris);
        puntol = (CheckBox) findViewById(R.id.puntolimpio);
        aceite = (CheckBox) findViewById(R.id.contnaranja);
    }

    @Override
    public void onClick(View v) {

        String dir=direccion.getText().toString();
        String prov=provincia.getText().toString();
        String loc=localidad.getText().toString();
        String num=numero.getText().toString();

        boolean azul = papel.isChecked();
        boolean amarillo=plastico.isChecked();
        boolean verde=vidrio.isChecked();
        boolean gris=organico.isChecked();
        boolean puntlimpio=puntol.isChecked();
        boolean naranja=aceite.isChecked();



        switch (v.getId()) {

            case R.id.añadircont:
                nuevocont(dir,prov,loc,num,azul,amarillo,verde,gris,puntlimpio,naranja);
                break;
            case R.id.cancelarid:
                Intent intent = new Intent(this,Home.class);
                startActivity(intent);
                break;

        }

    }


    public void nuevocont(String direccion,String provincia,String localidad,String numero,boolean papel,boolean plastico,boolean vidrio, boolean organico,boolean puntolimpio, boolean aceite){

        DatabaseReference refPush=ref.push();

        DatabaseReference refprovincia = refPush.child("Provincia");
        refprovincia.setValue(provincia);

        DatabaseReference reflocalidad = refPush.child("Localidad");
        reflocalidad.setValue(localidad);

        DatabaseReference refdireccion = refPush.child("Direccion");
        refdireccion.setValue(direccion);

        DatabaseReference refnumero = refPush.child("Numero");
        refnumero.setValue(numero);

        DatabaseReference refpapel = refPush.child("Contenedor azul");
        refpapel.setValue(papel);

        DatabaseReference refplastico = refPush.child("Contenedor amarillo");
        refplastico.setValue(plastico);

        DatabaseReference refvidrio = refPush.child("Contenedor verde");
        refvidrio.setValue(vidrio);

        DatabaseReference reforganico = refPush.child("Contenedor gris");
        reforganico.setValue(organico);

        DatabaseReference refpuntolimpio= refPush.child("Contenedor punto limpio");
        refpuntolimpio.setValue(puntolimpio);

        DatabaseReference refaceite = refPush.child("Contenedor naranja");
        refaceite.setValue(aceite);


    }


}
