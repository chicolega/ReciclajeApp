package com.example.scottowen.reciclajeappfire;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Login extends AppCompatActivity implements View.OnClickListener {

    static String usuario;


    FirebaseAuth.AuthStateListener mAuthListener;

    EditText emaile, passe;
    Button inicio, registro;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        emaile= (EditText) findViewById(R.id.NombreLogin);
        passe= (EditText) findViewById(R.id.ContraseñaLogin);

        System.out.println("lolin");

    }

    public void haciaregistro (View view) {
        Intent intent = new Intent(this, Registro.class);
        Button editText = (Button) findViewById(R.id.RegistroBotonLogin);
        startActivity(intent);

    }

    private void iniciarSesion(String email, String pass){

        FirebaseAuth.getInstance().signInWithEmailAndPassword(email, pass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()){
                    Toast.makeText(Login.this, "Acceso permitido", Toast.LENGTH_SHORT).show();
                    usuario=emaile.getText().toString();
                    Intent intent=new Intent(Login.this,Home.class);
                    startActivity(intent);

                }else{
                    Toast.makeText(Login.this, "Email o contraseña incorrectos", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    @Override
    public void onClick(View v) {

        String email = emaile.getText().toString();
        String pass=passe.getText().toString();

        switch (v.getId()) {

            case R.id.IniciobotonLogin:
                iniciarSesion(email, pass);

                break;
        }


    }
}
