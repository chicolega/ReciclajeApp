package com.example.scottowen.reciclajeappfire;

import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class Home extends AppCompatActivity implements View.OnClickListener {

    Button botonfiltro,botonlista,botonmosaico,botonmapa;

    TextView mail;

    ConstraintLayout fondo;

    LinearLayout lista;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        botonfiltro=(Button)findViewById(R.id.FiltrobotonHome);
        botonlista=(Button)findViewById(R.id.vistadelistabotonHome);
        botonmosaico=(Button)findViewById(R.id.vistamosaicabotonHome);
        botonmapa=(Button)findViewById(R.id.mapabotonHome);

        fondo = findViewById(R.id.fondo);

        lista = new LinearLayout(this);


       mail=(TextView)findViewById(R.id.NombreusuariolabelHome);

       mail.setText("Hola,"+Login.usuario);


        //AÑADIMOS LOS ELEMENTOS A LA LISTA;
        for (int i = 0; i < 5; i++) {
            TextView temporal = new TextView(this);
            temporal.setText("texto "+i);
            lista.addView(temporal);
        }
    }

    @Override
    public void onClick(View v) {
        fondo.removeView(lista);
        switch (v.getId()){
            case R.id.vistadelistabotonHome:
                lista.setOrientation(LinearLayout.VERTICAL);
                fondo.addView(lista);
                break;

            case R.id.vistamosaicabotonHome:
                    lista.setOrientation(LinearLayout.HORIZONTAL);
                    fondo.addView(lista);
                break;

            default:
                break;
        }


    }
}
