package com.example.scottowen.reciclajeappfire;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

public class Home extends AppCompatActivity implements View.OnClickListener {

    Button botonfiltro,botonlista,botonmosaico,botonmapa;

    TextView mail;

    ConstraintLayout fondo;

    LinearLayout lista;

    //conexión con la base de datos de Firebase
    static final FirebaseDatabase miBD = FirebaseDatabase.getInstance();
    DatabaseReference ref = miBD.getReference("Datos");


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        botonfiltro=(Button)findViewById(R.id.FiltrobotonHome);
        botonlista=(Button)findViewById(R.id.vistadelistabotonHome);
        botonmosaico=(Button)findViewById(R.id.vistamosaicabotonHome);
        botonmapa=(Button)findViewById(R.id.mapabotonHome);

        fondo = findViewById(R.id.fondo);
        lista = new LinearLayout(this);
        mail=(TextView)findViewById(R.id.NombreusuariolabelHome);
        mail.setText("");



        Query query = ref.orderByKey();
        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {


                    TextView temporal = new TextView(Home.this);
                    temporal.setText(""+dataSnapshot);
                    lista.addView(temporal);

                System.out.println(dataSnapshot);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });



        //AÑADIMOS LOS ELEMENTOS A LA LISTA;
       /*for (int i = 0; i < 5; i++) {
            TextView temporal = new TextView(this);
            temporal.setText("texto "+query);
            lista.addView(temporal);
        }*/
       }

    @Override
    public void onClick(View v) {
        fondo.removeView(lista);
        switch (v.getId()){
            case R.id.vistadelistabotonHome:
                lista.setOrientation(LinearLayout.VERTICAL);
                fondo.addView(lista);
                break;

            case R.id.vistamosaicabotonHome:
                    lista.setOrientation(LinearLayout.HORIZONTAL);
                    fondo.addView(lista);
                break;
            case R.id.añadirid:
                Intent intent = new Intent(this,Contenido.class);
                startActivity(intent);
                break;

            case R.id.FiltrobotonHome:
                intent=new Intent(this,Filtro.class);
                startActivity(intent);
            default:
                break;
        }
    }



}
