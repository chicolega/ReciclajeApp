package com.example.scottowen.accesoadatos;

import android.net.Uri;

import com.google.firebase.storage.StorageReference;

import java.util.List;


public interface IProductoDao {
    public void crearProducto(Producto producto);
    public void obtenerProducto();
    public void actualizarProducto(Producto producto);
    public void eliminarProducto(Producto producto);




}
