package com.example.scottowen.reciclajeappfire;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Registro extends AppCompatActivity implements View.OnClickListener {

    /**
     * @see Registro
     *
     * Esta clase crea un nuevo usuario mediante registro y usando firbase auth
     */
    EditText editTextEmail, editTextPassword;
    Button buttonLogin, buttonRegister;

    FirebaseAuth.AuthStateListener mAuthListener;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);
        editTextEmail=(EditText)findViewById(R.id.EmailtextoRegistro);
        editTextPassword=(EditText)findViewById(R.id.contraseñatextoregistro);




    }

    public void hacialogin (View view) {
        Intent intent = new Intent(this, Login.class);
        Button editText = (Button) findViewById(R.id.atrasbotonregistro);
        startActivity(intent);

    }

    public void registrar (String email, String pass){

        /**
         * Metodo que registra los usuario
         * @see registrar();
         */
        FirebaseAuth.getInstance().createUserWithEmailAndPassword(email, pass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()){
                    Toast.makeText(Registro.this, "Usuario registrado correctamente", Toast.LENGTH_SHORT).show();

                    Intent intent=new Intent(Registro.this,Home.class);
                    startActivity(intent);
                    finish();

                }else{
                    Toast.makeText(Registro.this, "Por favor, rellene los campos correctamente", Toast.LENGTH_SHORT).show();

                }
            }
        });


    }


    @Override
    public void onClick(View v) {

        String email = editTextEmail.getText().toString();
        String pass=editTextPassword.getText().toString();

        switch (v.getId()) {

            case R.id.Registrarbotonregistro:
                registrar(email, pass);

                break;
        }

    }
}
