package com.example.scottowen.reciclajeappfire;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Contenido extends AppCompatActivity implements View.OnClickListener {

    /**
     *
     * La funcion de esta clase es para que cree nuevos datos en la base de datos
     *
     */

    EditText provincia, localidad, direccion, numero;
    ImageButton papel, plastico, vidrio, organico, puntolimpio, aceite;
    public static PuntoReciclaje puntoActual;



    static FirebaseDatabase miBD = FirebaseDatabase.getInstance();
    DatabaseReference ref = miBD.getReference("Datos");

    //Asignamos cada campo texto y/o boton a la variable correspondiente.
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contenido);

        puntoActual = new PuntoReciclaje();
        provincia = (EditText) findViewById(R.id.provinciaid);
        localidad = (EditText) findViewById(R.id.localidaid);
        direccion = (EditText) findViewById(R.id.direccionid);
        numero = (EditText) findViewById(R.id.numeroid);

        papel=(ImageButton)findViewById(R.id.papelbotoncontenido);
        plastico=(ImageButton)findViewById(R.id.plasticobotoncontenido);
        vidrio=(ImageButton)findViewById(R.id.vidriobotoncontenido);
        organico=(ImageButton)findViewById(R.id.organicobotoncontenido);
        puntolimpio=(ImageButton)findViewById(R.id.puntolimpiobotoncontenido);
        aceite=(ImageButton)findViewById(R.id.aceitebotoncontenido);


    }

    @Override
    public void onClick(View v) {

        puntoActual.setProvincia(provincia.getText().toString());
        puntoActual.setLocalidad(localidad.getText().toString());
        puntoActual.setDireccion(direccion.getText().toString());
        puntoActual.setNumero(numero.getText().toString());

        //Segun su id hace una u otra accion.
        switch (v.getId()) {

            //Asigna a la base de datos si el contenedor esta o no.
        case R.id.papelbotoncontenido:

            if(puntoActual.contenedorAzul == false){
            papel.setBackgroundResource(R.drawable.contenedordebasurapf);
                puntoActual.contenedorAzul = true;
            }else{
                papel.setBackgroundResource(R.drawable.contenedordebasurap);
                puntoActual.contenedorAzul=false;
            }

            break;

            //Asigna a la base de datos si el contenedor esta o no.
        case R.id.plasticobotoncontenido:

            if(puntoActual.contenedorAmarillo== false){
                plastico.setBackgroundResource(R.drawable.contenedordebasuraplfull);
                puntoActual.contenedorAmarillo= true;
            }else{
                plastico.setBackgroundResource(R.drawable.contenedordebasurapl);
                puntoActual.contenedorAmarillo=false;
            }

        break;

            //Asigna a la base de datos si el contenedor esta o no.
        case R.id.vidriobotoncontenido:

            if(puntoActual.contenedorVerde == false){
                vidrio.setBackgroundResource(R.drawable.contenedordebasuravfull);
                puntoActual.contenedorVerde = true;
            }else{
                vidrio.setBackgroundResource(R.drawable.contenedordebasurav);
                puntoActual.contenedorVerde=false;
            }

        break;

            //Asigna a la base de datos si el contenedor esta o no.
        case R.id.organicobotoncontenido:

            if(puntoActual.contenedorGris == false){
                organico.setBackgroundResource(R.drawable.contenedordebasuraf);
                puntoActual.contenedorGris = true;
            }else{
                organico.setBackgroundResource(R.drawable.contenedordebasura);
                puntoActual.contenedorGris=false;
            }

        break;

            //Asigna a la base de datos si el contenedor esta o no.
        case R.id.puntolimpiobotoncontenido:

            if(puntoActual.puntoLimpio == false){
                puntolimpio.setBackgroundResource(R.drawable.contenedordebasurafull);
                puntoActual.puntoLimpio = true;
            }else{
                puntolimpio.setBackgroundResource(R.drawable.contenedorpuntolimpio);
                puntoActual.puntoLimpio=false;
            }
        break;

            //Asigna a la base de datos si el contenedor esta o no.
        case R.id.aceitebotoncontenido:
            if(puntoActual.contenedorNaranja == false){
                aceite.setBackgroundResource(R.drawable.contenedordebasuraacfull);
                puntoActual.contenedorNaranja = true;
            }else{
                aceite.setBackgroundResource(R.drawable.contenedordebasuraac);
                puntoActual.contenedorNaranja=false;
            }
        break;


            //Switch que añade puntoActual
            case R.id.añadircont:
                nuevocont(puntoActual);
                break;
            case R.id.cancelarid:
                Intent intent = new Intent(this,Home.class);
                startActivity(intent);

                break;

        }

    }

        /*En este metodo introduce todo los campos a la base de datos.*/

    public void nuevocont(PuntoReciclaje puntoActual){

        /**
         * Metodo que crea el nuevo contenido terminando la sentencia de creacion de datos y cerrando la actividad
         */

        ref.push().setValue(puntoActual);
        finish();


    }


}
