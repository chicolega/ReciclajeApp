package com.example.scottowen.accesoadatos;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class AdapterDatos extends RecyclerView.Adapter<AdapterDatos.ViewHolderDatos> {

    Context context;
    ArrayList<Producto> listaproducto;

    public AdapterDatos(Context c,ArrayList<Producto> list_Datos) {
        context =c;
        listaproducto = list_Datos;
    }

    @NonNull
    @Override
    public ViewHolderDatos onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

        return new ViewHolderDatos(LayoutInflater.from(context).inflate(R.layout.productos,viewGroup,false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolderDatos viewHolderDatos, int i) {
        viewHolderDatos.nombre.setText(listaproducto.get(i).getNombre());
        viewHolderDatos.fecha.setText(listaproducto.get(i).getFecha());
        viewHolderDatos.descripcion.setText(listaproducto.get(i).getDescripcion());
        String url = listaproducto.get(i).getImagen();
        Picasso
                .with(context)
                .load(url)
                .resize(250, 250)
                .centerCrop()
                .placeholder(R.drawable.ic_launcher_background)
                .into(ViewHolderDatos.imagenpro);
    }

    @Override
    public int getItemCount() {
        return listaproducto.size();
    }

    public static class ViewHolderDatos extends RecyclerView.ViewHolder {

        TextView nombre, fecha, descripcion;
        static ImageView imagenpro;


        public ViewHolderDatos(@NonNull View itemView) {
            super(itemView);
            nombre=itemView.findViewById(R.id.nombreproducto);
            fecha=itemView.findViewById(R.id.fechaproducto);
            descripcion=itemView.findViewById(R.id.descripcionproducto);
            imagenpro=itemView.findViewById(R.id.imagenproductos);

        }


    }
}
