package com.example.scottowen.reciclajeappfire;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

public class Filtro extends AppCompatActivity implements View.OnClickListener {

    DatabaseReference ref = Home.miBD.getReference("Datos");
    Button atras;

    EditText prov,loc,dir,num;
    String provincia,localidad,direccion,numero;

    Switch papel,plastico,vidrio,organico,aceite,puntlimp;
    Boolean contpapel,contplastico,contvidrio,contorganico,contaceite,contlimp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_filtro);
        atras=(Button)findViewById(R.id.atrasbotonfiltro);


        prov=findViewById(R.id.provinciatextofiltro);
        loc=findViewById(R.id.localidadtextofiltro);
        dir=findViewById(R.id.textobusquedadireccion);
        num=findViewById(R.id.numerotextofiltro);

        papel=(Switch)findViewById(R.id.contenedorazul);
        plastico=findViewById(R.id.contenedoramarillo);
        vidrio=findViewById(R.id.contendeorverde);
        organico=findViewById(R.id.contenedorgris);
        aceite=findViewById(R.id.contenedornaranja);
        puntlimp=findViewById(R.id.puntolimpiocontenedor);

    }

    @Override
    public void onClick(View v) {
        provincia=prov.getText().toString();
        localidad=loc.getText().toString();
        direccion=dir.getText().toString();
        numero=num.getText().toString();

        if(provincia.isEmpty()){
            Toast.makeText(this, "El campo provincia no debe estar vacio", Toast.LENGTH_SHORT).show();
        }

        switch (v.getId()) {
            case R.id.atrasbotonfiltro:
                Intent intent = new Intent(this, Home.class);
                startActivity(intent);
                finish();
                break;

            case R.id.busquedabutton:


                Query query = ref.orderByChild("provincia").equalTo(provincia);
                query.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                        for(DataSnapshot ds : dataSnapshot.getChildren()) {
                            PuntoReciclaje filtropr = ds.getValue(PuntoReciclaje.class);

                            //Si localidad esta vacia
                            if(localidad.isEmpty()){

                                //Si localidad y direccion estan vacias
                                if(direccion.isEmpty()){

                                    //Si localidad direccion y numero estan vacios
                                    if(numero.isEmpty()){
                                        //Comprueba que contenedor este marcado para buscar
                                        if((organico.isChecked()==true && filtropr.isContenedorGris()==true) || (papel.isChecked()==true && filtropr.isContenedorAzul()==true) || (plastico.isChecked()==true && filtropr.isContenedorAmarillo()) || (vidrio.isChecked()==true && filtropr.isContenedorVerde()) ||  (aceite.isChecked()==true && filtropr.isContenedorNaranja()) || (puntlimp.isChecked()==true && filtropr.isPuntoLimpio()) ) {
                                            System.out.println("filtrado solo por provincia" + filtropr.getDireccion());
                                        }
                                    //Si localidad y direccion esta vacia pero numero no
                                    }else{
                                        if(numero.equals(filtropr.getNumero())){
                                            //Comprueba que contenedor este marcado para buscar
                                            if((organico.isChecked()==true && filtropr.isContenedorGris()==true) || (papel.isChecked()==true && filtropr.isContenedorAzul()==true) || (plastico.isChecked()==true && filtropr.isContenedorAmarillo()) || (vidrio.isChecked()==true && filtropr.isContenedorVerde()) ||  (aceite.isChecked()==true && filtropr.isContenedorNaranja()) || (puntlimp.isChecked()==true && filtropr.isPuntoLimpio()) ) {
                                                System.out.println("Provincia, numero " + filtropr.getDireccion());
                                            }
                                        }
                                    }

                                 //Si localidad esta vacia pero direccion no
                                }else{

                                    //Si localidad y numero estan vacios pero direccion no
                                    if(numero.isEmpty()){
                                        //Comprueba que direccion sea igual
                                        if(direccion.equals(filtropr.getDireccion())){
                                            //Comprueba que contenedor este marcado para buscar
                                            if((organico.isChecked()==true && filtropr.isContenedorGris()==true) || (papel.isChecked()==true && filtropr.isContenedorAzul()==true) || (plastico.isChecked()==true && filtropr.isContenedorAmarillo()) || (vidrio.isChecked()==true && filtropr.isContenedorVerde()) ||  (aceite.isChecked()==true && filtropr.isContenedorNaranja()) || (puntlimp.isChecked()==true && filtropr.isPuntoLimpio()) ) {
                                                System.out.println("Provincia y direccion" + filtropr.getDireccion());
                                            }
                                        }

                                    //Si localidad esta vacia pero direccion y numeros no
                                    }else{
                                        if(direccion.equals(filtropr.getDireccion())&& numero.equals(filtropr.getNumero())){
                                            //Comprueba que contenedor este marcado para buscar
                                            if((organico.isChecked()==true && filtropr.isContenedorGris()==true) || (papel.isChecked()==true && filtropr.isContenedorAzul()==true) || (plastico.isChecked()==true && filtropr.isContenedorAmarillo()) || (vidrio.isChecked()==true && filtropr.isContenedorVerde()) ||  (aceite.isChecked()==true && filtropr.isContenedorNaranja()) || (puntlimp.isChecked()==true && filtropr.isPuntoLimpio()) ) {
                                                System.out.println("provincia numero y direccion");
                                            }
                                        }

                                    }

                                }
                            //Si localidad no esta vacia
                            }else{

                                //Si localidad no esta vacia pero direccion si
                                if(direccion.isEmpty()){

                                    //Si localidad no esta vacia pero direccion y numero si
                                    if(numero.isEmpty()){
                                        if(localidad.equals(filtropr.getLocalidad())) {
                                            if((organico.isChecked()==true && filtropr.isContenedorGris()==true) || (papel.isChecked()==true && filtropr.isContenedorAzul()==true) || (plastico.isChecked()==true && filtropr.isContenedorAmarillo()) || (vidrio.isChecked()==true && filtropr.isContenedorVerde()) ||  (aceite.isChecked()==true && filtropr.isContenedorNaranja()) || (puntlimp.isChecked()==true && filtropr.isPuntoLimpio()) ) {
                                                System.out.println("Provincia y localidad " + filtropr.getDireccion());
                                            }
                                        }

                                    //Si localidad no esta vacia direccion si pero numero no
                                    }else{
                                        if(localidad.equals(filtropr.getLocalidad())&&numero.equals(filtropr.getNumero())){
                                            if((organico.isChecked()==true && filtropr.isContenedorGris()==true) || (papel.isChecked()==true && filtropr.isContenedorAzul()==true) || (plastico.isChecked()==true && filtropr.isContenedorAmarillo()) || (vidrio.isChecked()==true && filtropr.isContenedorVerde()) ||  (aceite.isChecked()==true && filtropr.isContenedorNaranja()) || (puntlimp.isChecked()==true && filtropr.isPuntoLimpio()) ) {
                                                System.out.println("provincia,localidad,numero");
                                            }
                                        }
                                    }

                                //Si localidad y direccion no esta vacia
                                }else{

                                    //Si localidad y direccion no esta vacia pero numero si
                                    if(numero.isEmpty()){
                                        if(localidad.equals(filtropr.getLocalidad()) && direccion.equals(filtropr.getDireccion())){
                                            if((organico.isChecked()==true && filtropr.isContenedorGris()==true) || (papel.isChecked()==true && filtropr.isContenedorAzul()==true) || (plastico.isChecked()==true && filtropr.isContenedorAmarillo()) || (vidrio.isChecked()==true && filtropr.isContenedorVerde()) ||  (aceite.isChecked()==true && filtropr.isContenedorNaranja()) || (puntlimp.isChecked()==true && filtropr.isPuntoLimpio()) ) {
                                                System.out.println("provincia,localidad,direccion" + filtropr.getDireccion());
                                            }
                                        }

                                    //Si localidad , direccion ,numero  no esta vacia
                                    }else{
                                        if(localidad.equals(filtropr.getLocalidad())&& direccion.equals(filtropr.getDireccion())&& numero.equals(filtropr.getNumero())){
                                            if((organico.isChecked()==true && filtropr.isContenedorGris()==true) || (papel.isChecked()==true && filtropr.isContenedorAzul()==true) || (plastico.isChecked()==true && filtropr.isContenedorAmarillo()) || (vidrio.isChecked()==true && filtropr.isContenedorVerde()) ||  (aceite.isChecked()==true && filtropr.isContenedorNaranja()) || (puntlimp.isChecked()==true && filtropr.isPuntoLimpio()) ) {
                                                System.out.println("provincia,localidad,direccion,numero" + filtropr.getDireccion());
                                            }
                                        }
                                    }


                                }
                            }




                        }

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });


                break;
        }
    }
}
