package com.example.scottowen.reciclajeappfire;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class Home extends AppCompatActivity implements View.OnClickListener {

    Button botonfiltro,botonlista,botonmosaico,botonmapa;

    TextView mail;

    ConstraintLayout fondo;

    LinearLayout lista;

    //conexión con la base de datos de Firebase
    static final FirebaseDatabase miBD = FirebaseDatabase.getInstance();
    DatabaseReference ref;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        botonfiltro = (Button) findViewById(R.id.FiltrobotonHome);
        botonlista = (Button) findViewById(R.id.vistadelistabotonHome);
        botonmosaico = (Button) findViewById(R.id.vistamosaicabotonHome);
        botonmapa = (Button) findViewById(R.id.mapabotonHome);

        fondo = findViewById(R.id.fondo);
        lista = new LinearLayout(this);
        mail = (TextView) findViewById(R.id.NombreusuariolabelHome);
        mail.setText("");
        lista.setOrientation(LinearLayout.VERTICAL);
        fondo.addView(lista);
        Bundle extras = getIntent().getExtras();

        mostrarMejores();


   }



   public void mostrarMejores(){
       //Aqui realizamos la query que nos devolvera los mejor valorados
       ref = miBD.getReference("Datos");
       Query query = ref.orderByChild("valor").limitToFirst(2);
       query.addListenerForSingleValueEvent(new ValueEventListener() {
           @Override
           public void onDataChange(@NonNull DataSnapshot dataSnapshot) {


               for (DataSnapshot ds : dataSnapshot.getChildren()) {
                   PuntoReciclaje querypr = ds.getValue(PuntoReciclaje.class);
                   TextView temporal = new TextView(Home.this);
                   lista.addView(temporal);
                   temporal.setText(" Direccion:" + querypr.getDireccion() + " Localidad:" + querypr.getLocalidad());
               }

           }

           @Override
           public void onCancelled(@NonNull DatabaseError databaseError) {

           }
       });


   }


    @Override
    public void onClick(View v) {
        fondo.removeView(lista);
        switch (v.getId()){
            case R.id.vistadelistabotonHome:
                lista.setOrientation(LinearLayout.VERTICAL);
                fondo.addView(lista);
                break;

            case R.id.vistamosaicabotonHome:
                    lista.setOrientation(LinearLayout.HORIZONTAL);
                    fondo.addView(lista);
                break;
            case R.id.añadirid:
                Intent intent = new Intent(this,Contenido.class);
                startActivity(intent);
                break;

            case R.id.FiltrobotonHome:
                intent=new Intent(this,Filtro.class);
                startActivity(intent);
                finish();
            default:
                break;
        }
    }



}
