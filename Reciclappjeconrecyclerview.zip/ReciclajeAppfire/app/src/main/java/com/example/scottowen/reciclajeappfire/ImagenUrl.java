package com.example.scottowen.reciclajeappfire;

public class ImagenUrl {
    private String imageurl;

    public ImagenUrl() {
    }

    public ImagenUrl(String imageurl) {
        this.imageurl = imageurl;
    }

    public void setImageurl(String imageurl) {
        this.imageurl = imageurl;
    }
}
