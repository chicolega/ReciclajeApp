package com.example.scottowen.reciclajeappfire;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.constraint.ConstraintLayout;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

/**
 * Java class Home
 * La clase muestra la pgagina principal
 *
 *
 * @author Scott Owen
 * @version 1.00, 03 Dec 2018
 */

public class Home extends AppCompatActivity implements View.OnClickListener{


    Button botonfiltro, botonlista, botonmosaico, cerrarsesionboton;

    TextView mail;
     boolean vistamosaico=false;

    //Esto es el contenido de el layout busqueda.
    static Button atras;


    //conexión con la base de datos de Firebase
    static final FirebaseDatabase miBD = FirebaseDatabase.getInstance();
    DatabaseReference ref;


    //Prueba Recyclerview
    RecyclerView recyclerView;
    ArrayList<PuntoReciclaje> listcontenedores;
    Adaptador adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        //A la creacion de la actividad se deben enlazar los campos y botones con sus varibales correspondiente

        atras=findViewById(R.id.atrasbotonfiltro);
        botonfiltro = findViewById(R.id.FiltrobotonHome);
        botonlista = findViewById(R.id.vistadelistabotonHome);
        botonmosaico = findViewById(R.id.vistamosaicabotonHome);
        cerrarsesionboton=findViewById(R.id.cerrarsesionboton);

        recyclerView=findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        listcontenedores=new ArrayList<PuntoReciclaje>();

        //Y llamamos al metodo que muestra los mejores 5 puntos.
          mostrarMejores();
    }

    /**
     * * Metodo que crea los objetos y llama a la funcion
     */
    //Metodo que realiza la consulta de busqueda y lo muestra en un dialog.
    public void mostrarMejores() {

        //Aqui realizamos la consulta que nos devolvera los mejores valorados
        ref = miBD.getReference("Datos");
            Query query = ref.orderByChild("valor").limitToFirst(20);
            query.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    listcontenedores.removeAll(listcontenedores);

                    for (DataSnapshot ds : dataSnapshot.getChildren()) {
                        PuntoReciclaje querypr = ds.getValue(PuntoReciclaje.class);

                        listcontenedores.add(querypr);
                    }
                    adapter=new Adaptador(Home.this,listcontenedores);
                    recyclerView.setAdapter(adapter);
                }


                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.vistadelistabotonHome:
                vistamosaico=false;

                mostrarMejores();
                break;

            case R.id.vistamosaicabotonHome:
                vistamosaico=true;
                mostrarMejores();
                break;

            case R.id.anadirid:
                Intent intent = new Intent(this, Contenido.class);
                startActivity(intent);
                break;

            case R.id.FiltrobotonHome:
                setContentView(R.layout.busqueda);
                break;

            case R.id.cerrarsesionboton:
                finish();
                break;

        }
    }

}




