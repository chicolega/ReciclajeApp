package com.example.scottowen.reciclajeappfire;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class Login extends AppCompatActivity implements View.OnClickListener {

    /**
     * Java class Home
     * La clase muestra la pgagina principal
     *
     *
     * @author Scott Owen
     * @version 1.00, 03 Dec 2018
     */

    static String usuario;
    FirebaseAuth.AuthStateListener mAuthListener;
    EditText emaile, passe;

    private CheckBox recordarchebox;
    private SharedPreferences mPrefs;
    private static final String PREFS_NAME="PrefsFile";

    private CheckBox automaticacheckbox;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        mPrefs=getSharedPreferences(PREFS_NAME,MODE_PRIVATE);

        emaile= (EditText) findViewById(R.id.NombreLogin);
        passe= (EditText) findViewById(R.id.ContrasenaLogin);
        recordarchebox=(CheckBox)findViewById(R.id.recordarmecheckBox);

        getPreferencesData();



    }

    private void getPreferencesData() {
        SharedPreferences sp=getSharedPreferences(PREFS_NAME,MODE_PRIVATE);
        if(sp.contains("pref_name")){
            String recordaru=sp.getString("pref_name","No encontrado");
            emaile.setText(recordaru.toString());
        }
        if(sp.contains("pref_passw")){
            String recordarp=sp.getString("pref_passw","No encontrado");
            passe.setText(recordarp.toString());
        }

        if(sp.contains("pref_remember")){
            boolean recordarb=sp.getBoolean("pref_remember",false);
            recordarchebox.setChecked(recordarb);
        }

    }


    public void haciaregistro (View view) {
        Intent intent = new Intent(this, Registro.class);
        Button editText = (Button) findViewById(R.id.RegistroBotonLogin);
        startActivity(intent);

    }

    private void iniciarSesion(String email, String pass){

        /**
         * Metodo que  inicia sesion mediante la base de datos y el texrto introducido.
         *
         * Se usa firebase para eso
         */

        FirebaseAuth.getInstance().signInWithEmailAndPassword(email, pass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()){
                    Toast.makeText(Login.this, "Acceso permitido", Toast.LENGTH_SHORT).show();
                    usuario=emaile.getText().toString();
                    Intent intent=new Intent(Login.this,Home.class);
                    startActivity(intent);


                }else{
                    Toast.makeText(Login.this, "Email o contrasena incorrectos", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    @Override
    public void onClick(View v) {

        String email = emaile.getText().toString();
        String pass=passe.getText().toString();

        if(recordarchebox.isChecked()){
            Boolean boolischecked=recordarchebox.isChecked();
            SharedPreferences.Editor editor=mPrefs.edit();
            editor.putString("pref_name",emaile.getText().toString());
            editor.putString("pref_passw",passe.getText().toString());
            editor.putBoolean("pref_remember",boolischecked);

            editor.apply();

        }else{
            mPrefs.edit().clear().apply();
        }

        switch (v.getId()) {

            case R.id.IniciobotonLogin:
                iniciarSesion(email, pass);

                break;
        }


    }
}
