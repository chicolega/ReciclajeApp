package com.example.scottowen.accesoadatos;

import android.net.Uri;
import android.support.annotation.NonNull;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.util.ArrayList;
import java.util.List;
import android.content.ContentResolver;
import android.webkit.MimeTypeMap;
import android.widget.Toast;

public class ProductoDaoImpl implements IProductoDao {


    @Override
    public void crearProducto(Producto producto) {

        Agregarinventario.ref.child(producto.getUploadID()).setValue(producto);
    }


    @Override
    public void obtenerProducto() {


    }

    @Override
    public void actualizarProducto(Producto producto) {
        String codigo=producto.getUploadID();

        System.out.println("actuid"+codigo);
       // Agregarinventario.ref.child(producto.getUploadID()).setValue(producto);


    }

    @Override
    public void eliminarProducto(Producto producto) {
        String codigo=producto.getUploadID();

        System.out.println("deleid"+codigo);
        Agregarinventario.ref.child(producto.getUploadID()).removeValue();
    }



}
