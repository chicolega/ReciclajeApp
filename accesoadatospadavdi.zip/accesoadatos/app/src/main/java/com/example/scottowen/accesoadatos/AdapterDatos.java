package com.example.scottowen.accesoadatos;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.squareup.picasso.Picasso;

import java.io.Serializable;
import java.util.ArrayList;

import static android.support.v4.content.ContextCompat.startActivity;

public class AdapterDatos extends RecyclerView.Adapter<AdapterDatos.ViewHolderDatos> {

   static AdapterDatos productoslistadapater;
    static Context context;
    static ArrayList<Producto> listaproducto;



    static ProductoDaoImpl pdao=new ProductoDaoImpl();

    public AdapterDatos(Context c,ArrayList<Producto> list_Datos) {
        context =c;
        listaproducto = list_Datos;
    }

    @NonNull
    @Override
    public ViewHolderDatos onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

        return new ViewHolderDatos(LayoutInflater.from(context).inflate(R.layout.productos,viewGroup,false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolderDatos viewHolderDatos, int i) {
        viewHolderDatos.nombre.setText(listaproducto.get(i).getNombre());
        viewHolderDatos.fecha.setText(listaproducto.get(i).getFecha());
        viewHolderDatos.descripcion.setText(listaproducto.get(i).getDescripcion());
        viewHolderDatos.id.setText((listaproducto.get(i).getUploadID()));
        String url = listaproducto.get(i).getImagen();
        Picasso
                .with(context)
                .load(url)
                .resize(250, 250)
                .centerCrop()
                .placeholder(R.drawable.ic_launcher_background)
                .into(ViewHolderDatos.imagenpro);
    }

    @Override
    public int getItemCount() {
        return listaproducto.size();
    }

    public static class ViewHolderDatos extends RecyclerView.ViewHolder {

        TextView nombre, fecha, descripcion,id;
        static ImageView imagenpro;
        ImageButton editarbtn,eliminarbtn;


        public ViewHolderDatos(@NonNull View itemView) {
            super(itemView);
            nombre=itemView.findViewById(R.id.nombreproducto);
            fecha=itemView.findViewById(R.id.fechaproducto);
            descripcion=itemView.findViewById(R.id.descripcionproducto);
            imagenpro=itemView.findViewById(R.id.imagenproductos);
            id=itemView.findViewById(R.id.IDproducto);
            editarbtn=itemView.findViewById(R.id.editarboton);
            eliminarbtn=itemView.findViewById(R.id.eliminarboton);


            eliminarbtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {


                    pdao.eliminarProducto(listaproducto.get(getLayoutPosition()));
                    System.out.println("Esto es lo que se le pasa:"+listaproducto.get(getLayoutPosition()));

                }
            });

            editarbtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                   //Producto position=listaproducto.get(getLayoutPosition());
                    Intent intent=new Intent(context,Editar.class);
                    intent.putExtra("actualizar",listaproducto);


                }
            });

        }




    }
}
