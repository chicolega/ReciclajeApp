package com.example.scottowen.accesoadatos;

import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

public class Agregarinventario extends AppCompatActivity{

    Button agregar;


    public static Producto productos;

    EditText nombre,fecha,descripcion;


    static FirebaseStorage storagebd=FirebaseStorage.getInstance();
    static StorageReference storagereference=storagebd.getReference("Productos");

    static FirebaseDatabase miBD = FirebaseDatabase.getInstance();
    static DatabaseReference ref = miBD.getReference("Productos");


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agregarinventario);

        //Asigna el componente visual con los correspondientes inputs


        agregar=findViewById(R.id.addbutton);

        nombre=findViewById(R.id.nombreproducto);
        descripcion=findViewById(R.id.descripcionproducto);
        fecha=findViewById(R.id.fechaproducto);

        //Inicializa producto
        productos=new Producto();



        //Metodo agregar al clickar en boton agregar
        agregar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ProductoDaoImpl pdao=new ProductoDaoImpl();
                String nombrenew=nombre.getText().toString();
                String descripcionnew=descripcion.getText().toString();
                String fechanew=fecha.getText().toString();

                productos.setNombre(nombrenew);
                productos.setDescripcion(descripcionnew);
                productos.setFecha(fechanew);

                String codigo=Agregarinventario.ref.push().getKey();

                productos.setUploadID(codigo);

                pdao.crearProducto(productos);

                finish();
            }
        });


    }












}

