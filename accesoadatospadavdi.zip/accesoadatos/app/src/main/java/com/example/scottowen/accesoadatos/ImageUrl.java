package com.example.scottowen.accesoadatos;

public class ImageUrl {
    private String imageurl;

    public ImageUrl() {
    }

    public ImageUrl(String imageurl) {
        this.imageurl = imageurl;
    }

    public void setImageurl(String imageurl) {
        this.imageurl = imageurl;
    }
}
