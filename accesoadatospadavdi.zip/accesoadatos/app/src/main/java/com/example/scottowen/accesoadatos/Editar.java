package com.example.scottowen.accesoadatos;

import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

public class Editar extends AppCompatActivity {

    Button chooseedit,actualizar;

    ImageView imagenedit;

    public static Producto productos;
    EditText nombre,fecha,descripcion;
    TextView idproducto;



    private FirebaseStorage storagebd=FirebaseStorage.getInstance();
    StorageReference storagereference=storagebd.getReference("Productos");

    static FirebaseDatabase miBD = FirebaseDatabase.getInstance();
    DatabaseReference ref = miBD.getReference("Productos");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editar);

        idproducto=(TextView) findViewById(R.id.idedit);

        nombre=findViewById(R.id.Nombreeditar);
        descripcion=findViewById(R.id.Descripcioneditar);
        fecha=findViewById(R.id.fechaeditar);
        imagenedit=findViewById(R.id.imageViewedit);
        actualizar=findViewById(R.id.actualizareditar);


        productos=(Producto)getIntent().getExtras()("actualizacion");

        chooseedit=findViewById(R.id.chooseedit);

        idproducto.setText(productos.getUploadID());
        nombre.setText(productos.getNombre());
        descripcion.setText(productos.getDescripcion());
        fecha.setText(productos.getFecha());


        productos=new Producto();

        actualizar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               String  codigopro=idproducto.getText().toString();
               String nombreedit=nombre.getText().toString();
               String editdescripcion=descripcion.getText().toString();
               String editFecha=fecha.getText().toString();

                pdao.eliminarProducto(listaproducto.get(getLayoutPosition()));
                System.out.println(productos.getUploadID());

            }
        });

    }











}
