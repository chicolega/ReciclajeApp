package com.example.scottowen.accesoadatos;

import java.util.List;


public interface IProductoDao {
    public List<Producto> obtenerProducto();
    public Producto obtenerProducto(int id);
    public void actualizarProducto(Producto producto);
    public void eliminarProducto(Producto producto);

}
