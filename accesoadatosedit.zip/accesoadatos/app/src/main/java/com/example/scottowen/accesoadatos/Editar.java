package com.example.scottowen.accesoadatos;

import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

public class Editar extends AppCompatActivity {

    Button chooseedit,actualizar;

    ImageView imagenedit;
    private final int PICK_IMAGE_REQUEST=1;
    private Uri filePath;
    public static Producto productos;
    EditText nombre,fecha,descripcion,idproducto;

    String idproductoedit;


    private FirebaseStorage storagebd=FirebaseStorage.getInstance();
    StorageReference storagereference=storagebd.getReference("Productos");

    static FirebaseDatabase miBD = FirebaseDatabase.getInstance();
    DatabaseReference ref = miBD.getReference("Productos");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editar);

        chooseedit=findViewById(R.id.chooseedit);

        actualizar=findViewById(R.id.actualizareditar);

        nombre=findViewById(R.id.Nombreeditar);
        descripcion=findViewById(R.id.Descripcioneditar);
        fecha=findViewById(R.id.fechaeditar);
        imagenedit=findViewById(R.id.imageViewedit);
        idproducto=findViewById(R.id.idproductoeditar);

        productos=new Producto();

        chooseedit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                chooseImage();
            }
        });


        actualizar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                productos.setNombre(nombre.getText().toString());
                productos.setDescripcion(descripcion.getText().toString());
                productos.setFecha(fecha.getText().toString());
                productos.setUploadID(idproductoedit=idproducto.getText().toString());
                uploadFile(productos);
            }
        });

    }

    private void uploadFile(final Producto productos){
        if(filePath !=null){
            final StorageReference fileReference=storagereference.child(System.currentTimeMillis()+"."+getFileExtension(filePath));

            fileReference.putFile(filePath).addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {
                    Task<Uri> uriTask = task.getResult().getStorage().getDownloadUrl();
                    while(!uriTask.isComplete());
                    Uri downloadUrl = uriTask.getResult();

                    productos.setImagen(downloadUrl.toString());
                    System.out.println("Despues de subir la imagen la url de descarga es: " + productos.getImagen());
                    productos.setImagen(downloadUrl.toString());

                    editprod(idproductoedit);
                }
            });

        }else{
            Toast.makeText(this, "No hay archivos seleccionados", Toast.LENGTH_SHORT).show();
        }

    }


    public void editprod(String id){

        /**
         * Metodo que crea el nuevo contenido terminando la sentencia de creacion de datos y cerrando la actividad
         */

        String uploadID=id;

        productos.setUploadID(uploadID);
        System.out.println("La imagen antes de guardar en la BD es: " + productos.getImagen());
        ref.child(uploadID).setValue(productos);


        finish();


    }

    private void chooseImage(){
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent,PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode== PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() !=null){
            filePath =data.getData();
            Picasso.with(this).load(filePath).into(imagenedit);

        }

    }

    private String getFileExtension(Uri uri){

        ContentResolver cR=getContentResolver();
        MimeTypeMap mime =MimeTypeMap.getSingleton();


        return mime.getExtensionFromMimeType(cR.getType(uri));
    }

}
