package com.example.scottowen.accesoadatos;

import android.graphics.drawable.Drawable;

import java.util.ArrayList;
import java.util.List;

public class ProductoDaoImpl implements IProductoDao {

    List<Producto> productos;

    public ProductoDaoImpl() {
        productos = new ArrayList<>();
       // Producto producto1 = new Producto("Perrito","2","Un perro",9,null);
       // Producto producto2 = new Producto("Excelsior","3","Hakunamatata",13,null);
       // productos.add(producto1);
       // productos.add(producto2);
    }
    @Override
    public List<Producto> obtenerProducto() {
        return productos;
    }

    @Override
    public Producto obtenerProducto(int id) {
        return productos.get(id);
    }

    @Override
    public void actualizarProducto(Producto producto) {
     //   productos.get(producto.getUploadID()).setNombre(producto.getNombre());
     //   productos.get(producto.getId()).setDescripcion(producto.getDescripcion());
     //   System.out.println("Cliente con id: "+producto.getId()+" actualizado satisfactoriamente");
    }

    @Override
    public void eliminarProducto(Producto producto) {
    //    productos.remove(producto.getId());
     //   System.out.println("Cliente con id: "+producto.getId()+" elimnado satisfactoriamente");
    }
}
