package com.example.scottowen.reciclajeappfire;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

public class Contenido extends AppCompatActivity implements View.OnClickListener {

    /**
     * Java class Home
     * La clase muestra la pgagina principal
     *
     *
     * @author Scott Owen
     * @version 1.00, 03 Dec 2018
     */

    EditText provincia, localidad, direccion, numero;
    ImageButton papel, plastico, vidrio, organico, puntolimpio, aceite;
    public static PuntoReciclaje puntoActual;

    Button btnchoose,btoncamera;
    ImageView imagencontenedor;

    private final int PICK_IMAGE_REQUEST=1;

    private static final int CAMERA_REQUEST = 1888;
    private Uri filePath;

    private FirebaseStorage storagebd=FirebaseStorage.getInstance();
    StorageReference storagereference=storagebd.getReference("Contenedores");

    static FirebaseDatabase miBD = FirebaseDatabase.getInstance();
    DatabaseReference ref = miBD.getReference("Datos");

    //Asignamos cada campo texto y/o boton a la variable correspondiente.
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contenido);

        puntoActual = new PuntoReciclaje();
        provincia = (EditText) findViewById(R.id.provinciaid);
        localidad = (EditText) findViewById(R.id.localidaid);
        direccion = (EditText) findViewById(R.id.direccionid);
        numero = (EditText) findViewById(R.id.numeroid);

        papel=(ImageButton)findViewById(R.id.papelbotoncontenido);
        plastico=(ImageButton)findViewById(R.id.plasticobotoncontenido);
        vidrio=(ImageButton)findViewById(R.id.vidriobotoncontenido);
        organico=(ImageButton)findViewById(R.id.organicobotoncontenido);
        puntolimpio=(ImageButton)findViewById(R.id.puntolimpiobotoncontenido);
        aceite=(ImageButton)findViewById(R.id.aceitebotoncontenido);

        btoncamera=findViewById(R.id.camarabutton);
        btnchoose=findViewById(R.id.choosebutton);

        imagencontenedor=findViewById(R.id.imagenContenedor);


        btoncamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                captureImage();
            }
        });

        btnchoose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                chooseImage();
            }
        });

    }

    @Override
    public void onClick(View v) {

        puntoActual.setProvincia(provincia.getText().toString());
        puntoActual.setLocalidad(localidad.getText().toString());
        puntoActual.setDireccion(direccion.getText().toString());
        puntoActual.setNumero(numero.getText().toString());

        //Segun su id hace una u otra accion.
        switch (v.getId()) {

            //Asigna a la base de datos si el contenedor esta o no.
        case R.id.papelbotoncontenido:

            if(puntoActual.contenedorAzul == false){
            papel.setBackgroundResource(R.drawable.contenedordebasurapf);
                puntoActual.contenedorAzul = true;
            }else{
                papel.setBackgroundResource(R.drawable.contenedordebasurap);
                puntoActual.contenedorAzul=false;
            }

            break;

            //Asigna a la base de datos si el contenedor esta o no.
        case R.id.plasticobotoncontenido:

            if(puntoActual.contenedorAmarillo== false){
                plastico.setBackgroundResource(R.drawable.contenedordebasuraplfull);
                puntoActual.contenedorAmarillo= true;
            }else{
                plastico.setBackgroundResource(R.drawable.contenedordebasurapl);
                puntoActual.contenedorAmarillo=false;
            }

        break;

            //Asigna a la base de datos si el contenedor esta o no.
        case R.id.vidriobotoncontenido:

            if(puntoActual.contenedorVerde == false){
                vidrio.setBackgroundResource(R.drawable.contenedordebasuravfull);
                puntoActual.contenedorVerde = true;
            }else{
                vidrio.setBackgroundResource(R.drawable.contenedordebasurav);
                puntoActual.contenedorVerde=false;
            }

        break;

            //Asigna a la base de datos si el contenedor esta o no.
        case R.id.organicobotoncontenido:

            if(puntoActual.contenedorGris == false){
                organico.setBackgroundResource(R.drawable.contenedordebasuraf);
                puntoActual.contenedorGris = true;
            }else{
                organico.setBackgroundResource(R.drawable.contenedordebasura);
                puntoActual.contenedorGris=false;
            }

        break;

            //Asigna a la base de datos si el contenedor esta o no.
        case R.id.puntolimpiobotoncontenido:

            if(puntoActual.puntoLimpio == false){
                puntolimpio.setBackgroundResource(R.drawable.contenedordebasurafull);
                puntoActual.puntoLimpio = true;
            }else{
                puntolimpio.setBackgroundResource(R.drawable.contenedorpuntolimpio);
                puntoActual.puntoLimpio=false;
            }
        break;

            //Asigna a la base de datos si el contenedor esta o no.
        case R.id.aceitebotoncontenido:
            if(puntoActual.contenedorNaranja == false){
                aceite.setBackgroundResource(R.drawable.contenedordebasuraacfull);
                puntoActual.contenedorNaranja = true;
            }else{
                aceite.setBackgroundResource(R.drawable.contenedordebasuraac);
                puntoActual.contenedorNaranja=false;
            }
        break;


            //Switch que anade puntoActual
            case R.id.anadircont:
                nuevocont(puntoActual);
                break;
            case R.id.cancelarid:
                Intent intent = new Intent(this,Home.class);
                startActivity(intent);

                break;

        }

    }

        /*En este metodo introduce todo los campos a la base de datos.*/




    public void nuevocont(final PuntoReciclaje puntoActual){

        /**
         * Metodo que crea el nuevo contenido terminando la sentencia de creacion de datos y cerrando la actividad
         */
        storagereference;
        finish();


    }
    private String getFileExtension(Uri uri){

        ContentResolver cR=getContentResolver();
        MimeTypeMap mime =MimeTypeMap.getSingleton();


        return mime.getExtensionFromMimeType(cR.getType(uri));
    }

    private void captureImage(){
        Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(cameraIntent, CAMERA_REQUEST);


    }

    private void chooseImage(){
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent,PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode== PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() !=null){
            filePath =data.getData();
            Picasso.with(this).load(filePath).into(imagencontenedor);

        }

        if (requestCode == CAMERA_REQUEST && resultCode == Activity.RESULT_OK) {
            Bitmap photo = (Bitmap) data.getExtras().get("data");
            imagencontenedor.setImageBitmap(photo);
        }
    }
}
